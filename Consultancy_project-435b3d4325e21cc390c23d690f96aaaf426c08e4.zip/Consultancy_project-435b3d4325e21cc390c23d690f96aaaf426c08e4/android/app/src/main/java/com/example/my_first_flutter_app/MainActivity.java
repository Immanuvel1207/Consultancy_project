package com.example.Nanjundeshwara_Stores;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
